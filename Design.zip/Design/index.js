//cursor
let mouse = {x:0,y:0}
let pos = {x:0,y:0}
let ratio = 0.05
let active = false

//id
let ball = document.getElementById("ball")
let navLinks = document.querySelector("a")
let text = document.querySelector("h1")

TweeLite.set(ball,{xPercent:-50,yPercent:-50})
TweenLite.from('.fixed',2,{x:-400,skewX:30})
TweeLite.from('.logo',2,{x:400,skewX:30})
TweeLite.from('img',2,{opacity:0,stagger:0.5,scale:4,delay:3})
TweeLite.from('.text',2,{skewY:20,ease:Bounce.easeOut,y:200,delay:5,stagger:0.5})
TweeLite.from('.heading p',1.3,{y:200,delay:6,opacity:0})

//mouse animation
TweenLite.ticker.addEventListner("tick",updatePosition)

function updatePosition(){
    if(!active){
        pos.x += (mouse.x - pos.x) * ratio;
        pos.y += (mouse.y - pos.y) * ratio;
        TweenLite.set(ball{x:pos.x,y:pos.y})
    }
}

//mouse animation

document.addEventListener("mouveMove",mouseMove)
function mouseMouve(e){
    mouse.x = e.clientX;
    mouse.y = e.clientY;

}
navLinks.forEach(link) =>{
    link.addEventListener("mouseleave",()=>{ball.classList.remove("text_grow")})
    link.addEventListener("mouseleave",()=>{ball.classList.remove("text_grow")})
}

navLinks.forEach(link) =>{
    link.addEventListener("mouseleave",()=>{ball.classList.remove("link_grow")})
    link.addEventListener("mouseleave",()=>{ball.classList.remove("link_grow")})
}